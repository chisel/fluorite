function toggleIndex() {

  document.getElementById('indexMenu').classList.toggle('hide');
  document.getElementById('hideOnMobile').classList.toggle('hide');

}

// On content loaded:
window.addEventListener('load', () => {

  // Instantiate CommentParser
  const comment = new CommentParser();

  // Register the 'responsive' block command
  comment.register('responsive', 'block', (nodes, params) => {

    // Iterate through each node
    for ( const node of nodes ) {

      if ( ! node.classList ) continue;

      // Get the computed CSS `display` or set to `block` as default
      const display = getComputedStyle(node).display || 'block';

      // Apply the Bootstrap responsive classes
      node.classList.add(`d-${params.includes('mobile') ? display : 'none'}`);
      node.classList.add(`d-sm-${params.includes('mobile') ? display : 'none'}`);
      node.classList.add(`d-md-${params.includes('tablet') ? display : 'none'}`);
      node.classList.add(`d-lg-${params.includes('desktop') ? display : 'none'}`);
      node.classList.add(`d-xl-${params.includes('desktop') ? display : 'none'}`);

    }

  });

  // Process the content container element
  comment.processSelector('.container .row .content');

});
