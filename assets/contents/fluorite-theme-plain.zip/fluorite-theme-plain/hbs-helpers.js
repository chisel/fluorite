module.exports = {

  getIndentation: (level) => `${40 + (level * 20)}px`,

  isTopSection: (level) => level === 0

};
