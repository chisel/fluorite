function toggleIndex() {

  document.getElementById('indexMenu').classList.toggle('hide');
  document.getElementById('hideOnMobile').classList.toggle('hide');

}

// On content loaded:
window.addEventListener('load', () => {

  // Instantiate CommentParser
  const comment = new CommentParser();

  // Register the 'responsive' block command
  comment.register('responsive', 'block', (nodes, args) => {

    // Iterate through each node
    for ( const node of nodes ) {

      if ( ! node.classList ) continue;

      // Get the computed CSS `display` or set to `block` as default
      const display = getComputedStyle(node).display || 'block';

      // Apply the Bootstrap responsive classes
      node.classList.add(`d-${args.includes('mobile') ? display : 'none'}`);
      node.classList.add(`d-sm-${args.includes('mobile') ? display : 'none'}`);
      node.classList.add(`d-md-${args.includes('tablet') ? display : 'none'}`);
      node.classList.add(`d-lg-${args.includes('desktop') ? display : 'none'}`);
      node.classList.add(`d-xl-${args.includes('desktop') ? display : 'none'}`);

    }

  });

  // Parse the content container element
  comment.parse(document.querySelector('.container .row .content'));

});
